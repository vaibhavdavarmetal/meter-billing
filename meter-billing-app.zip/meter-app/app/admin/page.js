"use client";
import { useState } from "react";

function money(n) {
  if (!isFinite(n)) return "—";
  return "₹" + Math.round(n).toLocaleString("en-IN");
}
function thisPeriod() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export default function Admin() {
  const [pw, setPw] = useState("");
  const [period, setPeriod] = useState(thisPeriod());
  const [data, setData] = useState(null);
  const [prev, setPrev] = useState({}); // manually entered previous readings per slug
  const [totalBill, setTotalBill] = useState("");
  const [err, setErr] = useState("");

  const load = async () => {
    setErr("");
    try {
      const res = await fetch(`/api/readings?period=${period}&pw=${encodeURIComponent(pw)}`);
      if (!res.ok) throw new Error();
      setData(await res.json());
    } catch {
      setErr("Wrong password or no data.");
    }
  };

  const waText = (propName, tName, prevV, currV, units, amount, mode, extra) => {
    const base = `Electricity bill — ${period}\n${propName} · ${tName}\n\nPrevious: ${prevV}\nCurrent: ${currV}\nUnits used: ${units}\n`;
    const tail = mode === "rate"
      ? `Rate: ₹${extra}/unit\n\nAmount payable: ${money(amount)}`
      : `Share of total bill (${money(extra)})\n\nAmount payable: ${money(amount)}`;
    return base + tail;
  };

  return (
    <div style={{ maxWidth: 560, margin: "0 auto", padding: "24px 16px" }}>
      <h1 style={{ fontFamily: "Georgia, serif" }}>Billing — Admin</h1>

      {!data && (
        <div style={{ background: "#fff", border: "1px solid #e4ddd0", borderRadius: 14, padding: 18 }}>
          <label style={lbl}>Period (YYYY-MM)</label>
          <input value={period} onChange={(e) => setPeriod(e.target.value)} style={inp} />
          <label style={lbl}>Admin password</label>
          <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} style={inp} />
          {err && <p style={{ color: "#c0392b" }}>{err}</p>}
          <button onClick={load} style={btn}>Load readings</button>
        </div>
      )}

      {data && Object.entries(data.properties).map(([pkey, prop]) => {
        // compute units for proportional
        const rows = prop.tenants.map((t) => {
          const r = data.readings[t.slug];
          const currV = r ? r.reading : null;
          const prevV = Number(prev[t.slug] || 0);
          const units = currV == null ? null : Math.max(0, currV - prevV);
          return { t, currV, prevV, units, photoUrl: r?.photoUrl };
        });
        const totalUnits = rows.reduce((s, r) => s + (r.units || 0), 0);
        const billNum = Number(totalBill) || 0;

        return (
          <div key={pkey} style={{ marginTop: 20 }}>
            <h2 style={{ fontSize: 18 }}>{prop.name}</h2>
            {prop.mode === "proportional" && (
              <div style={{ margin: "8px 0" }}>
                <label style={lbl}>Actual total bill for {prop.name}</label>
                <input inputMode="decimal" value={totalBill} onChange={(e) => setTotalBill(e.target.value.replace(/[^0-9.]/g, ""))} style={inp} placeholder="₹" />
              </div>
            )}
            {rows.map(({ t, currV, prevV, units, photoUrl }) => {
              const amount = currV == null ? null
                : prop.mode === "rate" ? units * prop.rate
                : totalUnits === 0 ? 0 : (units / totalUnits) * billNum;
              const extra = prop.mode === "rate" ? prop.rate : billNum;
              return (
                <div key={t.slug} style={card}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <strong>{t.name}</strong>
                    <span style={{ fontFamily: "Georgia, serif", fontSize: 20, color: "#3b5b6b" }}>{amount == null ? "no reading" : money(amount)}</span>
                  </div>
                  <div style={{ display: "flex", gap: 8, alignItems: "flex-end", margin: "8px 0" }}>
                    <div style={{ flex: 1 }}>
                      <label style={lblSm}>Previous</label>
                      <input inputMode="numeric" value={prev[t.slug] || ""} onChange={(e) => setPrev({ ...prev, [t.slug]: e.target.value.replace(/[^0-9.]/g, "") })} style={inpSm} placeholder="0" />
                    </div>
                    <div style={{ flex: 1 }}>
                      <label style={lblSm}>Current (submitted)</label>
                      <input value={currV ?? ""} readOnly style={{ ...inpSm, background: "#eef3f5" }} />
                    </div>
                    <div style={{ textAlign: "center", minWidth: 50 }}>
                      <div style={{ fontWeight: 700, color: "#3b5b6b" }}>{units ?? "—"}</div>
                      <div style={{ fontSize: 10, color: "#8a8375" }}>units</div>
                    </div>
                  </div>
                  {photoUrl && <a href={photoUrl} target="_blank" style={{ fontSize: 13, color: "#3b5b6b" }}>View meter photo →</a>}
                  {amount != null && (
                    <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                      <a
                        href={`https://wa.me/?text=${encodeURIComponent(waText(prop.name, t.name, prevV, currV, units, amount, prop.mode, extra))}`}
                        target="_blank"
                        style={{ ...btn, textDecoration: "none", textAlign: "center", flex: 1, background: "#3f6b4a" }}
                      >
                        Send bill on WhatsApp
                      </a>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

const lbl = { display: "block", fontSize: 12, color: "#8a8375", fontWeight: 700, margin: "10px 0 4px", textTransform: "uppercase", letterSpacing: 0.5 };
const lblSm = { display: "block", fontSize: 10, color: "#8a8375", fontWeight: 700, marginBottom: 2, textTransform: "uppercase" };
const inp = { width: "100%", boxSizing: "border-box", border: "1px solid #e4ddd0", borderRadius: 8, padding: 12, fontSize: 16, background: "#faf7f0" };
const inpSm = { width: "100%", boxSizing: "border-box", border: "1px solid #e4ddd0", borderRadius: 8, padding: 8, fontSize: 15, background: "#faf7f0" };
const btn = { width: "100%", background: "#1f2421", color: "#fff", border: "none", borderRadius: 10, padding: 14, fontWeight: 700, cursor: "pointer", marginTop: 10 };
const card = { background: "#fff", border: "1px solid #e4ddd0", borderRadius: 12, padding: 14, marginTop: 10 };
